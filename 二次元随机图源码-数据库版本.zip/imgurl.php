<?php
//数据库连接地址
$servername = "localhost";
//数据库用户名
$username = "root";
//数据库用户密码
$password = "root";
//数据库名
$dbname = "root";
// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// 连接失败提示
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}
$sqlid = "SELECT MAX(id) AS id FROM imgurl";
$sqlid = $conn->query($sqlid);
//取数据库最大ID值
$row_id=mysqli_fetch_assoc($sqlid);
//取随机数字
$id=rand(1,$row_id['id']); 
//连接数据库
$sql = "select * from imgurl where id='$id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // 输出数据
    while($row = $result->fetch_assoc()) {
        header("Location:".$row["imgurl"]);       
    }
} else {
    echo "数组不存在 或者图片出错！";
}
?>